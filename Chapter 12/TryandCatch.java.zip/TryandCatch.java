import java.util.*;

class Untitled {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int array[] = new int[100];
		
		try {
			for (int i = 0; i < array.length; i++){
				array[i] = (int)(Math.random() * 100);}
			System.out.print("Please enter the index of the array: ");
			int index = input.nextInt();
			System.out.println("Your number in the array is: " + array[index]);
		}
		catch (Exception ex){
			System.out.println("Array index is out of bounds");
		}
		
	}
}
import java.awt.*;

class Untitled {
	public static void main(String[] args) {
		class Rectangle {
			//The length and width
			double width = 1;
			double height = 1;
			//Construct a rectangle object
			Rectangle() {
			}
			//Construct a rectangle object
			Rectangle(double newWidth, double newHeight) {
			width = newWidth;
			height = newHeight;
			}
			
			//Return the area of this rectangle
			double getArea() {
				return width * height;
			}
			//Return the perimeter of this rectangle
			double getPerimeter() {
				return 2 * width + 2 * height;
			}
			//Set a new width and height for this circle
			void setWidth(double newWidth, double newHeight){
				width = newWidth;
				height = newHeight;
			}
		}
		Rectangle rectangle1 = new Rectangle();
		rectangle1.width = 4;
		rectangle1.height = 40;
		System.out.println("The area of the first Rectangle of width " + rectangle1.width + " and height " + rectangle1.height + " is  " + rectangle1.getArea());
		System.out.println("And the perimeter is " + rectangle1.getPerimeter());
		Rectangle rectangle2 = new Rectangle();
		rectangle2.width = 3.5;
		rectangle2.height = 35.9;
		System.out.println("The area of the second Rectangle of width " + rectangle2.width + " and height " + rectangle2.height + " is  " + rectangle2.getArea());
		System.out.println("And the perimeter is " + rectangle2.getPerimeter());
	}
}
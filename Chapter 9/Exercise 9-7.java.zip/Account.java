import java.sql.*;
import java.util.Date;

class Untitled {
	public static void main(String[] args) {
		class Account {
			private int id = 0;
			private double balance = 0;
			private double annualInterestRate = 0;
			private Date dateCreated = new Date();
			Account(){
			}
			Account(int newId, double newBalance){
				id = newId;
				balance = newBalance;
			}
			private void setBalance(double newBalance){
				this.balance = newBalance;
			}
			private void setId(int newId){
				this.id = newId;
			}
			private void setAnnualInterestRate(double newAnnualInterestRate){
				this.annualInterestRate = newAnnualInterestRate;
			}
			private Date setDateCreated(){
				return dateCreated;
			}
			double getMonthlyInterestRate(){
				return (annualInterestRate/100) / 12;
			}
			double getMonthlyInterest(){
				return balance * getMonthlyInterestRate();
			}
			double withdraw(){
				return 2500;
			}
			double deposit(){
				return 3000;
			}
			void setAccount(int newId, double newBalance){
				id = newId;
				balance = newBalance;
			}
		}
		Account account1 = new Account();
		account1.id = 1122;
		account1.balance = 20000 - account1.withdraw() + account1.deposit();
		account1.annualInterestRate = 4.5;
		
		System.out.println("The balance is: " + account1.balance);
		System.out.println("The monthly interest " + account1.getMonthlyInterest() + " and the date " + account1.setDateCreated());
	}
}

package Demo;
import java.util.Scanner;
import java.io.*;

public class Encode {
	public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        //Prompt the user to enter input file and output file name
        System.out.print("Enter input file name: ");
        String inFile = input.next();
        System.out.print("Enter output file name: ");
        String outFile = input.next();

        try ( //Create two random access files
            RandomAccessFile source = new RandomAccessFile(inFile, "Source");
            RandomAccessFile target = new RandomAccessFile(outFile, "Target")
            ){
                //Add 5 to every byte read from Source then write to to Target
                int r = 0;
                source.seek(0); // move the file pointer to the start
                while ((r = source.read()) != -1) {
                    target.write(((byte)r) + 5);
                }
            }


    }
}
import java.sql.*;
import java.util.Date;
import java.util.*;

class Untitled {
	public static void main(String[] args) {
		/* test everything the assignment asks*/
		Scanner input = new Scanner(System.in);
		Account myAccount1 = new Account(0, 100);
		System.out.print("Welcome to your Checking account. \nWould you like to deposit or withdraw? \n'0' for deposit and '1' for withdraw: ");
		int choice = input.nextInt();
		if (choice == 1){
			System.out.print("How much would you like to withdraw: ");
			double withDraw = input.nextInt();
			while (withDraw >= 500){
				System.out.println("Withdraw can't exceed $500, please try again");
				System.out.print("How much would you like to withdraw: ");
				withDraw = input.nextInt();
			}
			System.out.println(myAccount1.toString() + myAccount1.withdraw(withDraw));}
		if (choice == 0){
			System.out.print("How much would you like to deposit: ");
			double deposit = input.nextInt();
			System.out.println(myAccount1.toString() + myAccount1.deposit(deposit));}	}
}
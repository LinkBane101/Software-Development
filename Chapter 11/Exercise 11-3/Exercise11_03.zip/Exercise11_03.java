import java.sql.*;
import java.util.Date;
import java.util.*;

class Exercise11_03 {
	public static void main(String[] args) {
		/* test everything the assignment asks*/
		Scanner input = new Scanner(System.in);
		Account myAccount1 = new Account(0, 100);
		System.out.print("Welcome to your Checking account. \nWould you like to deposit or withdraw? \n'0' for deposit and '1' for withdraw: ");
		int choice = input.nextInt();
		if (choice == 1){
			System.out.print("How much would you like to withdraw: ");
			double withDraw = input.nextInt();
			while (withDraw >= 500){
				System.out.println("Withdraw can't exceed $500, please try again");
				System.out.print("How much would you like to withdraw: ");
				withDraw = input.nextInt();
			}
			System.out.println(myAccount1.toString() + myAccount1.withdraw(withDraw));}
		if (choice == 0){
			System.out.print("How much would you like to deposit: ");
			double deposit = input.nextInt();
			System.out.println(myAccount1.toString() + myAccount1.deposit(deposit));}
	
//		Scanner input = new Scanner(System.in);
//	}
//	
//	checkingAccount accounts[] = new checkingAccount[3];
//	
//	accounts[0] = new checkingAccount();
//	accounts[1] = new Account(1, 100);
//	accounts[2] = new Account(2, 100);
//	
//	int choice = 4;
//	while (choice == 4){
//		System.out.print("Please enter your Id: ");
//		int user = input.nextInt();
//		while (user < 0 && user > accounts.length){
//			System.out.print("Wrong id please try again: ");
//			user = input.nextInt();}
//		if (user >= 0 && user <= accounts.length){
//			
//			choice = 0;
//			while(choice != 4){
//				System.out.println("Enter 1 to view current balance");
//				System.out.println("Enter 2 to withdraw");
//				System.out.println("Enter 3 to deposit");
//				System.out.println("Enter 4 to exit to main menu");
//				System.out.print("What would you like to do: ");
//				choice = input.nextInt();
//				while (choice < 0 && choice > 4){
//					System.out.print("Not a valid response. Please try again.");
//					System.out.println("Enter 1 to view current balance");
//					System.out.println("Enter 2 to withdraw");
//					System.out.println("Enter 3 to deposit");
//					System.out.println("Enter 4 to exit to main menu");
//					System.out.print("What would you like to do: ");
//					choice = input.nextInt();
//				}
//				if(choice == 1)
//				System.out.println("The balance is: " + accounts[user].balance);
//				else if(choice == 2){
//					System.out.print("How much would you like to withdraw: ");
//					int withDraw = input.nextInt();
//					accounts[user].balance = accounts[0].balance - withDraw;
//					System.out.println("Your account balance is: " + accounts[user].balance);}
//				else if(choice == 3){
//					System.out.print("How much would you like to deposit: ");
//					int putIn = input.nextInt();
//					accounts[user].balance = accounts[user].balance + putIn;
//					System.out.println("Your account balance is: " + accounts[user].balance);}}}
//	}
		}
}

import java.util.*;

class Untitled {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int value = input.nextInt();
		if (MyInteger.isEven(value)){
			System.out.println("Is even");
		}
		else if (MyInteger.isOdd(value))
		System.out.println("Is odd");
		if (MyInteger.isPrime(value)){
			System.out.println("Is prime");
		}
	}
}
		class MyInteger {
			int value = 0;
			
			
			MyInteger(int newValue){
				value = newValue;
			}
			int MyInteger(){
				return value;
			}
			boolean isEven(){
				if(value % 2 == 0)
				return true;
				else
					return false;
			}
			static boolean isEven(int value) {
				if(value % 2 == 0)
				return true;
				else
					return false;
			}
			static boolean isEven(MyInteger i) {
				if(i.value % 2 == 0)
				return true;
				else
					return false;
			}
			boolean isOdd(){
				if(value % 2 != 0)
				return true;
				else
					return false;
			}
			static boolean isOdd(MyInteger j) {
				if(j.value % 2 != 0)
				return true;
				else
					return false;
			}
			static boolean isOdd(int value) {
				if(value % 2 != 0)
				return true;
				else
					return false;
			}
			boolean isPrime(){
				if (value <= 1)
				return false;
				for (int i = 2; i<=Math.sqrt(value); i++){
					if(value % i == 0){
						return false;}}
				return true;
			}
			static boolean isPrime(int value) {
				if (value <= 1)
				return false;
				for (int i = 2; i<=Math.sqrt(value); i++){
					if(value % i == 0){
						return false;}}
				return true;
			}
			static boolean isPrime(MyInteger p) {
				if (p.value <= 1)
				return false;
				for (int i = 2; i<=Math.sqrt(p.value); i++){
					if(p.value % i == 0){
						return false;}}
				return true;
			}
			boolean equals(int value){
				if (this.value == value){
					return true;
				}else{
					return false;
				}
		}
		static boolean isEquals(int value) {
			if (value == value){
				return true;
			}else{
				return false;
			}
		}
		static char parseInt(char[] value){
			Scanner input = new Scanner(System.in);
			char numeric[] = new char[5];
			for (int i = 0; i < numeric.length; i++){
				System.out.print("Keep entering numbers up to 5: ");
				numeric[i] = input.next().charAt(i);
			}
			int newInteger[] = new int[numeric.length];
		for (int i = 0; i < numeric.length; i++){
			newInteger[i] = numeric[i];
		}
			return 1;
		}
		static String parseInt(String value){
			String word = "0";	
			int number = Integer.parseInt(word);
			return word;
			}
			void setMyInteger(int newValue){
				value = newValue;
			}
		}
